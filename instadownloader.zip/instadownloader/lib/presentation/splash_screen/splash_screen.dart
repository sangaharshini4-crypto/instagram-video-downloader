import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  late AnimationController _logoAnimationController;
  late AnimationController _progressAnimationController;
  late Animation<double> _logoScaleAnimation;
  late Animation<double> _logoFadeAnimation;
  late Animation<double> _progressAnimation;

  bool _isInitialized = false;
  String _initializationStatus = 'Initializing...';
  Timer? _splashTimer;

  @override
  void initState() {
    super.initState();
    _setupAnimations();
    _initializeApp();
  }

  void _setupAnimations() {
    // Logo animation controller
    _logoAnimationController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );

    // Progress animation controller
    _progressAnimationController = AnimationController(
      duration: const Duration(milliseconds: 2000),
      vsync: this,
    );

    // Logo scale animation
    _logoScaleAnimation = Tween<double>(
      begin: 0.5,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _logoAnimationController,
      curve: Curves.elasticOut,
    ));

    // Logo fade animation
    _logoFadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _logoAnimationController,
      curve: Curves.easeIn,
    ));

    // Progress animation
    _progressAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _progressAnimationController,
      curve: Curves.easeInOut,
    ));

    // Start logo animation
    _logoAnimationController.forward();
  }

  Future<void> _initializeApp() async {
    try {
      // Start progress animation
      _progressAnimationController.forward();

      // Simulate initialization steps
      await _checkStoragePermissions();
      await _validateNetworkConnectivity();
      await _loadUserPreferences();
      await _prepareVideoParsingEngines();

      setState(() {
        _isInitialized = true;
        _initializationStatus = 'Ready!';
      });

      // Wait for animations to complete before navigation
      _splashTimer = Timer(const Duration(milliseconds: 500), () {
        _navigateToNextScreen();
      });
    } catch (e) {
      setState(() {
        _initializationStatus = 'Initialization failed';
      });

      // Show error and retry after delay
      Timer(const Duration(seconds: 2), () {
        _initializeApp();
      });
    }
  }

  Future<void> _checkStoragePermissions() async {
    setState(() {
      _initializationStatus = 'Checking storage permissions...';
    });
    await Future.delayed(const Duration(milliseconds: 600));
  }

  Future<void> _validateNetworkConnectivity() async {
    setState(() {
      _initializationStatus = 'Validating network connectivity...';
    });
    await Future.delayed(const Duration(milliseconds: 500));
  }

  Future<void> _loadUserPreferences() async {
    setState(() {
      _initializationStatus = 'Loading user preferences...';
    });
    await Future.delayed(const Duration(milliseconds: 400));
  }

  Future<void> _prepareVideoParsingEngines() async {
    setState(() {
      _initializationStatus = 'Preparing video parsing engines...';
    });
    await Future.delayed(const Duration(milliseconds: 700));
  }

  void _navigateToNextScreen() {
    // Navigate to main dashboard (route will be handled by routing infrastructure)
    if (mounted) {
      Navigator.pushReplacementNamed(context, '/dashboard');
    }
  }

  @override
  void dispose() {
    _logoAnimationController.dispose();
    _progressAnimationController.dispose();
    _splashTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Set system UI overlay style
    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.light,
        systemNavigationBarColor: AppTheme.lightTheme.primaryColor,
        systemNavigationBarIconBrightness: Brightness.light,
      ),
    );

    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              AppTheme.lightTheme.primaryColor,
              AppTheme.lightTheme.primaryColor.withValues(alpha: 0.8),
              AppTheme.lightTheme.colorScheme.secondary,
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Spacer to push content to center
              const Spacer(flex: 2),

              // Animated Logo Section
              AnimatedBuilder(
                animation: _logoAnimationController,
                builder: (context, child) {
                  return Transform.scale(
                    scale: _logoScaleAnimation.value,
                    child: Opacity(
                      opacity: _logoFadeAnimation.value,
                      child: _buildLogoSection(),
                    ),
                  );
                },
              ),

              SizedBox(height: 8.h),

              // Loading Section
              _buildLoadingSection(),

              // Spacer to balance layout
              const Spacer(flex: 3),

              // App Version and Copyright
              _buildFooterSection(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLogoSection() {
    return Column(
      children: [
        // App Logo with Download Icon
        Container(
          width: 25.w,
          height: 25.w,
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.2),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: Colors.white.withValues(alpha: 0.3),
              width: 2,
            ),
          ),
          child: Stack(
            alignment: Alignment.center,
            children: [
              // Main Instagram icon
              CustomIconWidget(
                iconName: 'camera_alt',
                color: Colors.white,
                size: 12.w,
              ),
              // Download indicator
              Positioned(
                bottom: 2.w,
                right: 2.w,
                child: Container(
                  width: 6.w,
                  height: 6.w,
                  decoration: BoxDecoration(
                    color: AppTheme.getSuccessColor(false),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: Colors.white,
                      width: 1.5,
                    ),
                  ),
                  child: CustomIconWidget(
                    iconName: 'download',
                    color: Colors.white,
                    size: 3.w,
                  ),
                ),
              ),
            ],
          ),
        ),

        SizedBox(height: 4.h),

        // App Name
        Text(
          'InstaDownloader',
          style: AppTheme.lightTheme.textTheme.headlineMedium?.copyWith(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            letterSpacing: 1.2,
          ),
        ),

        SizedBox(height: 1.h),

        // App Tagline
        Text(
          'Download Instagram Videos Instantly',
          style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
            color: Colors.white.withValues(alpha: 0.9),
            fontWeight: FontWeight.w400,
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  Widget _buildLoadingSection() {
    return Column(
      children: [
        // Progress Indicator
        SizedBox(
          width: 60.w,
          child: AnimatedBuilder(
            animation: _progressAnimation,
            builder: (context, child) {
              return LinearProgressIndicator(
                value: _progressAnimation.value,
                backgroundColor: Colors.white.withValues(alpha: 0.3),
                valueColor: AlwaysStoppedAnimation<Color>(
                  Colors.white,
                ),
                minHeight: 4,
              );
            },
          ),
        ),

        SizedBox(height: 3.h),

        // Initialization Status
        AnimatedSwitcher(
          duration: const Duration(milliseconds: 300),
          child: Text(
            _initializationStatus,
            key: ValueKey(_initializationStatus),
            style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
              color: Colors.white.withValues(alpha: 0.8),
              fontWeight: FontWeight.w400,
            ),
            textAlign: TextAlign.center,
          ),
        ),

        SizedBox(height: 2.h),

        // Loading Dots Animation
        _buildLoadingDots(),
      ],
    );
  }

  Widget _buildLoadingDots() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(3, (index) {
        return AnimatedBuilder(
          animation: _progressAnimationController,
          builder: (context, child) {
            final delay = index * 0.2;
            final animationValue =
                (_progressAnimation.value - delay).clamp(0.0, 1.0);
            final opacity = (animationValue * 2).clamp(0.0, 1.0);

            return Container(
              margin: EdgeInsets.symmetric(horizontal: 1.w),
              child: Opacity(
                opacity: opacity,
                child: Container(
                  width: 2.w,
                  height: 2.w,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
              ),
            );
          },
        );
      }),
    );
  }

  Widget _buildFooterSection() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 8.w),
      child: Column(
        children: [
          // App Version
          Text(
            'Version 1.0.0',
            style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
              color: Colors.white.withValues(alpha: 0.7),
              fontSize: 10.sp,
            ),
          ),

          SizedBox(height: 1.h),

          // Copyright
          Text(
            '© 2025 InstaDownloader. All rights reserved.',
            style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
              color: Colors.white.withValues(alpha: 0.6),
              fontSize: 9.sp,
            ),
            textAlign: TextAlign.center,
          ),

          SizedBox(height: 2.h),
        ],
      ),
    );
  }
}
